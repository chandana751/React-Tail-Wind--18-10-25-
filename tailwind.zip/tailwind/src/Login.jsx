import React, { useState } from 'react';
import Button from './Button';
import FormContainer from './FormContainer';

const Login = () => {
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');

  const handleLogin = () => {
    alert(`Logging in:\nEmail: ${email}\nPassword: ${password}`);
  };

  return (
    <FormContainer title="Login">
      <input
        type="email"
        placeholder="Email"
        value={email}
        onChange={e => setEmail(e.target.value)}
        className="input-field"
      />
      <input
        type="password"
        placeholder="Password"
        value={password}
        onChange={e => setPassword(e.target.value)}
        className="input-field"
      />
      <Button text="Login" onClick={handleLogin} style={{ width: '100%', marginTop: '10px' }} />
      <p className="forgot-text">Forgot password?</p>
    </FormContainer>
  );
};

export default Login;
