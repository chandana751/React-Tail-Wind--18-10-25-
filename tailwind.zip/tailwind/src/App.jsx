// src/App.jsx
import React, { useState } from "react";
import {
  BrowserRouter as Router,
  Routes,
  Route,
  NavLink,
  useNavigate,
} from "react-router-dom";

// ---------- Reusable Button Component ----------
const Button = ({ text, onClick, type = "button", style = {}, children }) => {
  return (
    <button
      type={type}
      onClick={onClick}
      className="custom-button"
      style={style}
    >
      {children || text}
    </button>
  );
};

// ---------- Reusable Form Container ----------
const FormContainer = ({ title, children }) => {
  return (
    <div className="form-card">
      <h2 className="form-title">{title}</h2>
      {children}
    </div>
  );
};

// ---------- Login Page ----------
const Login = () => {
  const navigate = useNavigate();
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");

  const handleLogin = () => {
    alert(`Logging in:\nEmail: ${email}\nPassword: ${password}`);
    navigate("/register");
  };

  return (
    <div className="page-center">
      <FormContainer title="Login">
        <input
          type="email"
          placeholder="Email"
          value={email}
          onChange={(e) => setEmail(e.target.value)}
          className="input-field"
        />
        <input
          type="password"
          placeholder="Password"
          value={password}
          onChange={(e) => setPassword(e.target.value)}
          className="input-field"
        />
        <Button
          text="Login"
          onClick={handleLogin}
          style={{ width: "100%", marginTop: "10px" }}
        />
        <p className="switch-text">
          Don’t have an account?{" "}
          <NavLink to="/register" className="link">
            Register
          </NavLink>
        </p>
      </FormContainer>
    </div>
  );
};

// ---------- Register Page ----------
const Register = () => {
  const navigate = useNavigate();
  const [name, setName] = useState("");
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [confirmPassword, setConfirmPassword] = useState("");

  const handleRegister = () => {
    if (password !== confirmPassword) {
      alert("Passwords do not match!");
      return;
    }
    alert(`Registered:\nName: ${name}\nEmail: ${email}`);
    navigate("/login");
  };

  return (
    <div className="page-center">
      <FormContainer title="Register">
        <input
          type="text"
          placeholder="Name"
          value={name}
          onChange={(e) => setName(e.target.value)}
          className="input-field"
        />
        <input
          type="email"
          placeholder="Email"
          value={email}
          onChange={(e) => setEmail(e.target.value)}
          className="input-field"
        />
        <input
          type="password"
          placeholder="Password"
          value={password}
          onChange={(e) => setPassword(e.target.value)}
          className="input-field"
        />
        <input
          type="password"
          placeholder="Confirm Password"
          value={confirmPassword}
          onChange={(e) => setConfirmPassword(e.target.value)}
          className="input-field"
        />
        <Button
          text="Register"
          onClick={handleRegister}
          style={{ width: "100%", marginTop: "10px" }}
        />
        <p className="switch-text">
          Already have an account?{" "}
          <NavLink to="/login" className="link">
            Login
          </NavLink>
        </p>
      </FormContainer>
    </div>
  );
};

// ---------- App ----------
export default function App() {
  return (
    <Router>
      <Routes>
        <Route path="/login" element={<Login />} />
        <Route path="/register" element={<Register />} />
        <Route path="*" element={<Login />} />
      </Routes>

      {/* ---------- Inline CSS ---------- */}
      <style>{`
        body, html, #root {
          margin: 0;
          height: 100%;
          font-family: 'Poppins', sans-serif;
          background: linear-gradient(135deg, #667eea, #764ba2);
          display: flex;
          justify-content: center;
          align-items: center;
        }
        .page-center {
          display: flex;
          justify-content: center;
          align-items: center;
          min-height: 100vh;
        }
        .form-card {
          background-color: #fff;
          padding: 30px;
          border-radius: 12px;
          width: 320px;
          box-shadow: 0 5px 15px rgba(0, 0, 0, 0.1);
          text-align: center;
        }
        .form-title {
          margin-bottom: 20px;
          color: #333;
        }
        .input-field {
          width: 100%;
          padding: 10px;
          margin-bottom: 12px;
          border-radius: 6px;
          border: 1px solid #ccc;
          outline: none;
          font-size: 1rem;
        }
        .custom-button {
          background-color: #667eea;
          color: white;
          padding: 12px;
          border: none;
          border-radius: 8px;
          font-size: 1rem;
          cursor: pointer;
          transition: background-color 0.3s;
        }
        .custom-button:hover {
          background-color: #5a67d8;
        }
        .switch-text {
          margin-top: 15px;
          color: #555;
        }
        .link {
          color: #667eea;
          text-decoration: none;
          font-weight: 600;
        }
        .link:hover {
          text-decoration: underline;
        }
      `}</style>
    </Router>
  );
}
