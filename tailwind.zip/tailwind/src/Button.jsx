import React from 'react';
import './Button.css';

const Button = ({ text, onClick, type = "button", style = {}, children }) => {
  return (
    <button
      type={type}
      onClick={onClick}
      className="custom-button"
      style={style}
    >
      {children || text}
    </button>
  );
};

export default Button;
